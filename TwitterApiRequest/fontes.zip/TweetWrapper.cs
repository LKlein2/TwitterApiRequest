﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TwitterApiRequest
{
    public class TweetWrapper
    {
        public List<RecordModel> recordModel = new List<RecordModel>();
    }
}
